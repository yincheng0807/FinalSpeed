package net.fs.utils;

public interface LogListener {
	
	public void onAppendContent(LogOutputStream los,String text);
	
}
