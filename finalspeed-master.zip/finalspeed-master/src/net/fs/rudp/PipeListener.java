// Copyright (c) 2015 D1SM.net

package net.fs.rudp;

public interface PipeListener {

	void pipeClose();
	
}
